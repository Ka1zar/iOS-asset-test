//
//  TestAppTests.swift
//  TestAppTests
//
//  Created by Lam Nguyen Nhat on 19/9/25.
//

import Testing

struct TestAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
